import React, { useEffect, useMemo, useState } from "react";
import {
  X, User, Clock, ChevronRight, ChevronLeft, Check, Loader2, Key, Users, Plus
} from "lucide-react";
import { ethers } from "ethers";
import {
  getSigner, getAccessControl, getTimeBoundPermissions, signAuthMessage
} from "../../utils/blockchain";
import toast from "react-hot-toast";

const EMPTY_ATTR = { key: "", value: "" };

const EXPIRY_PRESETS = [
  { label: "1 Hour", seconds: 3600 },
  { label: "24 Hours", seconds: 86400 },
  { label: "7 Days", seconds: 604800 },
  { label: "30 Days", seconds: 2592000 },
];

// ─── Real-world access policy templates ──────────────────────────────────────────
// Each template defines:
//   policy    → attribute tags written to the FILE (definePolicy) — all must match
//   recipient → bootstrap attributes stamped on the RECIPIENT (grantAccess)
// The recipient will be granted access only when their on-chain attributes
// satisfy every tag in the file policy.
const POLICY_TEMPLATES = [
  {
    id: "cardiologists",
    label: "Cardiologists only",
    emoji: "🪬",
    description: "Only doctors tagged with department:cardiology can open this file",
    policy:    [{ key: "role", value: "doctor" }, { key: "department", value: "cardiology" }],
    recipient: [{ key: "role", value: "doctor" }, { key: "department", value: "cardiology" }],
  },
  {
    id: "any-doctor",
    label: "Any registered doctor",
    emoji: "🏥",
    description: "Any wallet with role:doctor passes automatically",
    policy:    [{ key: "role", value: "doctor" }],
    recipient: [{ key: "role", value: "doctor" }],
  },
  {
    id: "senior-lawyers",
    label: "Senior lawyers only",
    emoji: "⚖️",
    description: "Lawyers with clearance:senior — junior lawyers are blocked",
    policy:    [{ key: "role", value: "lawyer" }, { key: "clearance", value: "senior" }],
    recipient: [{ key: "role", value: "lawyer" }, { key: "clearance", value: "senior" }],
  },
  {
    id: "cs-professors",
    label: "CS professors only",
    emoji: "🎓",
    description: "Professors in the CS department — other departments are blocked",
    policy:    [{ key: "role", value: "professor" }, { key: "department", value: "cs" }],
    recipient: [{ key: "role", value: "professor" }, { key: "department", value: "cs" }],
  },
  {
    id: "senior-auditors",
    label: "Senior auditors only",
    emoji: "🔍",
    description: "Auditors with clearance:level-3 — level-1 auditors cannot access",
    policy:    [{ key: "role", value: "auditor" }, { key: "clearance", value: "level-3" }],
    recipient: [{ key: "role", value: "auditor" }, { key: "clearance", value: "level-3" }],
  },
  {
    id: "payroll-hr",
    label: "HR / Payroll managers",
    emoji: "💼",
    description: "HR managers with payroll clearance — regular employees are blocked",
    policy:    [{ key: "role", value: "hr-manager" }, { key: "clearance", value: "payroll" }],
    recipient: [{ key: "role", value: "hr-manager" }, { key: "clearance", value: "payroll" }],
  },
  {
    id: "executives",
    label: "Level-3 executives only",
    emoji: "🏢",
    description: "Top-level executives — managers and employees cannot access",
    policy:    [{ key: "role", value: "executive" }, { key: "clearance", value: "level-3" }],
    recipient: [{ key: "role", value: "executive" }, { key: "clearance", value: "level-3" }],
  },
];

function formatAttributes(attrs) {
  return attrs
    .map((attr) => ({ key: attr.key.trim(), value: attr.value.trim() }))
    .filter((attr) => attr.key && attr.value)
    .map((attr) => `${attr.key}:${attr.value}`);
}

function hashAttributes(attrs) {
  return formatAttributes(attrs).map((attr) => ethers.utils.keccak256(ethers.utils.toUtf8Bytes(attr)));
}

export default function ShareModal({ file, onClose, account }) {
  const [step, setStep] = useState(1);
  const [mode, setMode] = useState("direct"); // direct | group

  const [recipient, setRecipient] = useState("");
  const [expiry, setExpiry] = useState(86400);
  const [filePolicyAttrs, setFilePolicyAttrs] = useState([{ ...EMPTY_ATTR }]);
  const [recipientAttrs, setRecipientAttrs] = useState([{ ...EMPTY_ATTR }]);

  const [groups, setGroups] = useState([]);
  const [groupsLoading, setGroupsLoading] = useState(false);
  const [selectedGroupId, setSelectedGroupId] = useState("");

  const [showCreateGroup, setShowCreateGroup] = useState(false);
  const [newGroupName, setNewGroupName] = useState("");
  const [newGroupMembers, setNewGroupMembers] = useState("");

  const [txStatus, setTxStatus] = useState({ step: 0, done: false, error: null });
  const [isSharing, setIsSharing] = useState(false);
  // Tracks which policy template is currently selected so it can be highlighted.
  const [selectedTemplate, setSelectedTemplate] = useState(null);

  if (!file) return null;

  const expiryLabel = EXPIRY_PRESETS.find((p) => p.seconds === expiry)?.label || `${expiry}s`;
  const selectedGroup = useMemo(
    () => groups.find((g) => g.groupId === selectedGroupId) || null,
    [groups, selectedGroupId]
  );
  const filePolicyTags = useMemo(() => formatAttributes(filePolicyAttrs), [filePolicyAttrs]);
  const directProgressSteps = useMemo(
    () => filePolicyTags.length > 0
      ? [
          { n: 1, label: "Writing ABAC file policy (AccessControl)..." },
          { n: 2, label: "Granting direct access (AccessControl)..." },
          { n: 3, label: "Setting time-bound rules (TimeBoundPermissions)..." },
        ]
      : [
          { n: 1, label: "Granting direct access (AccessControl)..." },
          { n: 2, label: "Setting time-bound rules (TimeBoundPermissions)..." },
        ],
    [filePolicyTags]
  );
  const groupProgressSteps = useMemo(
    () => filePolicyTags.length > 0
      ? [
          { n: 1, label: "Writing ABAC file policy (AccessControl)..." },
          { n: 2, label: "Wrapping file key to group and storing share..." },
        ]
      : [
          { n: 1, label: "Wrapping file key to group and storing share..." },
        ],
    [filePolicyTags]
  );

  const addAttributeRow = (setter) => setter((current) => [...current, { ...EMPTY_ATTR }]);

  const updateAttributeRow = (setter, index, field, value) => {
    setter((current) => current.map((attr, attrIndex) => (
      attrIndex === index ? { ...attr, [field]: value } : attr
    )));
  };

  const removeAttributeRow = (setter, index) => {
    setter((current) => {
      const next = current.filter((_, attrIndex) => attrIndex !== index);
      return next.length > 0 ? next : [{ ...EMPTY_ATTR }];
    });
  };

  const renderAttributeEditor = ({ title, subtitle, attrs, setter }) => (
    <div className="bg-gray-50 rounded-xl p-4 border border-gray-100 space-y-3">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h4 className="text-sm font-semibold text-gray-800">{title}</h4>
          <p className="text-xs text-gray-400 mt-1">{subtitle}</p>
        </div>
        <button
          onClick={() => addAttributeRow(setter)}
          className="text-xs text-electric-600 hover:text-electric-700 font-medium inline-flex items-center gap-1"
        >
          <Plus className="w-3.5 h-3.5" /> Add
        </button>
      </div>

      <div className="space-y-2">
        {attrs.map((attr, index) => (
          <div key={`${title}-${index}`} className="flex items-center gap-2">
            <input
              className="input-field flex-1 py-2 text-xs"
              placeholder="role"
              value={attr.key}
              onChange={(e) => updateAttributeRow(setter, index, "key", e.target.value)}
            />
            <span className="text-gray-400 font-medium">:</span>
            <input
              className="input-field flex-1 py-2 text-xs"
              placeholder="doctor"
              value={attr.value}
              onChange={(e) => updateAttributeRow(setter, index, "value", e.target.value)}
            />
            <button onClick={() => removeAttributeRow(setter, index)} className="text-red-400 hover:text-red-600 text-lg leading-none px-2">
              &times;
            </button>
          </div>
        ))}
      </div>
    </div>
  );

  const loadGroups = async () => {
    if (!account) return;
    setGroupsLoading(true);
    try {
      const signer = await getSigner();
      const auth = await signAuthMessage(signer);
      const res = await fetch("/api/groups", {
        headers: {
          "x-user-address": auth.address,
          "x-signature": auth.signature,
          "x-message": auth.message,
        },
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to load groups");
      setGroups(data.groups || []);
      if (!selectedGroupId && data.groups?.length) {
        setSelectedGroupId(data.groups[0].groupId);
      }
    } catch (err) {
      toast.error(err.message || "Failed to load groups");
    } finally {
      setGroupsLoading(false);
    }
  };

  useEffect(() => {
    if (mode === "group") {
      loadGroups();
    }
  }, [mode]);

  const createGroup = async () => {
    if (!newGroupName.trim()) {
      toast.error("Group name is required");
      return;
    }

    const memberAddresses = newGroupMembers
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean)
      .filter((v, i, arr) => arr.indexOf(v) === i)
      .map((address) => ({ address }));

    try {
      const signer = await getSigner();
      const auth = await signAuthMessage(signer);

      const res = await fetch("/api/groups", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-user-address": auth.address,
          "x-signature": auth.signature,
          "x-message": auth.message,
        },
        body: JSON.stringify({
          name: newGroupName.trim(),
          members: memberAddresses,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to create group");

      toast.success("Group created");
      setNewGroupName("");
      setNewGroupMembers("");
      setShowCreateGroup(false);
      await loadGroups();
      setSelectedGroupId(data.group.groupId);
    } catch (err) {
      toast.error(err.message || "Failed to create group");
    }
  };

  const handleShareDirect = async () => {
    const signer = await getSigner();
    const accessControl = await getAccessControl(signer);
    const timeBound = await getTimeBoundPermissions(signer);
    const policyHashes = hashAttributes(filePolicyAttrs);
    // Strict RBAC mode: role attributes are issued only by trusted issuers,
    // so direct sharing no longer stamps recipient attributes.
    const recipientHashes = [];

    let currentStep = 0;

    if (policyHashes.length > 0) {
      currentStep = 1;
      setTxStatus({ step: currentStep, done: false, error: null });
      const txPolicy = await accessControl.definePolicy(file.id, policyHashes);
      await txPolicy.wait();
    }

    currentStep = policyHashes.length > 0 ? 2 : 1;
    setTxStatus({ step: currentStep, done: false, error: null });
    const tx1 = await accessControl.grantAccess(file.id, recipient, recipientHashes);
    await tx1.wait();

    currentStep = policyHashes.length > 0 ? 3 : 2;
    setTxStatus({ step: currentStep, done: false, error: null });
    const tx2 = await timeBound.grantTimedAccess(recipient, file.id, expiry);
    await tx2.wait();

    setTxStatus({ step: currentStep, done: true, error: null });
  };

  const handleShareGroup = async () => {
    const signer = await getSigner();
    const accessControl = await getAccessControl(signer);
    const auth = await signAuthMessage(signer);
    const policyHashes = hashAttributes(filePolicyAttrs);

    let currentStep = 0;

    if (policyHashes.length > 0) {
      currentStep = 1;
      setTxStatus({ step: currentStep, done: false, error: null });
      const txPolicy = await accessControl.definePolicy(file.id, policyHashes);
      await txPolicy.wait();
    }

    currentStep = policyHashes.length > 0 ? 2 : 1;
    setTxStatus({ step: currentStep, done: false, error: null });

    const res = await fetch("/api/groups/share", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-user-address": auth.address,
        "x-signature": auth.signature,
        "x-message": auth.message,
      },
      body: JSON.stringify({
        groupId: selectedGroupId,
        fileId: file.id,
        expiryDurationSeconds: expiry,
      }),
    });

    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "Group share failed");

    setTxStatus({ step: currentStep, done: true, error: null });
  };

  const handleShare = async () => {
    if (mode === "direct" && !recipient.match(/^0x[0-9a-fA-F]{40}$/)) {
      toast.error("Enter a valid recipient wallet address");
      return;
    }
    if (mode === "group" && !selectedGroupId) {
      toast.error("Select a group");
      return;
    }

    setIsSharing(true);
    try {
      if (mode === "direct") {
        await handleShareDirect();
        toast.success(`File shared with ${recipient.slice(0, 8)}...`);
      } else {
        await handleShareGroup();
        toast.success(`File shared to group ${selectedGroup?.name || ""}`);
      }
      setTimeout(() => onClose(), 1600);
    } catch (err) {
      setTxStatus((s) => ({ ...s, error: err.message || "Share failed" }));
      toast.error(err.message || "Share failed");
    } finally {
      setIsSharing(false);
    }
  };

  return (
    <div className="modal-backdrop" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="modal-box animate-slide-up">
        <div className="flex items-center justify-between p-6 border-b border-gray-100">
          <div>
            <h2 className="text-lg font-bold text-gray-900">Share File</h2>
            <p className="text-sm text-gray-400 mt-0.5 truncate max-w-xs" title={file.fileName}>{file.fileName}</p>
          </div>
          <button onClick={onClose} className="btn-icon"><X className="w-4 h-4" /></button>
        </div>

        <div className="flex items-center gap-2 px-6 py-4 border-b border-gray-50">
          {[1, 2, 3].map((s) => (
            <React.Fragment key={s}>
              <div className={`step-dot ${step === s ? "active" : step > s ? "done" : "pending"}`}>
                {step > s ? <Check className="w-3.5 h-3.5" /> : s}
              </div>
              {s < 3 && <div className={`flex-1 h-px ${step > s ? "bg-electric-300" : "bg-gray-200"}`} />}
            </React.Fragment>
          ))}
        </div>

        <div className="p-6">
          {step === 1 && (
            <div className="animate-fade-in space-y-4">
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => setMode("direct")}
                  className={`py-2.5 rounded-xl text-sm font-medium border transition-all ${
                    mode === "direct" ? "bg-electric-500 border-electric-500 text-white" : "border-gray-200 text-gray-600"
                  }`}
                >
                  <span className="inline-flex items-center gap-2"><User className="w-4 h-4" /> Direct Wallet</span>
                </button>
                <button
                  onClick={() => setMode("group")}
                  className={`py-2.5 rounded-xl text-sm font-medium border transition-all ${
                    mode === "group" ? "bg-electric-500 border-electric-500 text-white" : "border-gray-200 text-gray-600"
                  }`}
                >
                  <span className="inline-flex items-center gap-2"><Users className="w-4 h-4" /> Group</span>
                </button>
              </div>

              {mode === "direct" ? (
                <div>
                  <h3 className="text-sm font-semibold text-gray-800 mb-1 flex items-center gap-2">
                    <User className="w-4 h-4 text-electric-500" /> Recipient wallet
                  </h3>
                  <p className="text-xs text-gray-400 mb-3">Recipient needs MetaMask with this address</p>
                  <input
                    className="input-field font-mono"
                    placeholder="0x... wallet address"
                    value={recipient}
                    onChange={(e) => setRecipient(e.target.value)}
                    autoFocus
                  />
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-semibold text-gray-800 flex items-center gap-2">
                      <Users className="w-4 h-4 text-electric-500" /> Group selection
                    </h3>
                    <button
                      onClick={() => setShowCreateGroup((v) => !v)}
                      className="text-xs text-electric-600 hover:text-electric-700 font-medium inline-flex items-center gap-1"
                    >
                      <Plus className="w-3.5 h-3.5" /> New Group
                    </button>
                  </div>

                  {showCreateGroup && (
                    <div className="bg-gray-50 rounded-xl p-3 space-y-2 border border-gray-100">
                      <input
                        className="input-field"
                        placeholder="Group name"
                        value={newGroupName}
                        onChange={(e) => setNewGroupName(e.target.value)}
                      />
                      <textarea
                        className="input-field min-h-[76px]"
                        placeholder="Member wallet addresses (comma-separated)"
                        value={newGroupMembers}
                        onChange={(e) => setNewGroupMembers(e.target.value)}
                      />
                      <button onClick={createGroup} className="btn-primary text-xs py-2 px-3">Create Group</button>
                    </div>
                  )}

                  <select
                    value={selectedGroupId}
                    onChange={(e) => setSelectedGroupId(e.target.value)}
                    className="input-field"
                    disabled={groupsLoading}
                  >
                    <option value="">{groupsLoading ? "Loading groups..." : "Select a group"}</option>
                    {groups.map((g) => (
                      <option key={g.groupId} value={g.groupId}>
                        {g.name} ({g.memberCount} members)
                      </option>
                    ))}
                  </select>

                  {selectedGroup && (
                    <div className="text-xs text-gray-500">
                      Sharing to <span className="font-semibold text-gray-700">{selectedGroup.name}</span> ({selectedGroup.memberCount} active members)
                    </div>
                  )}
                </div>
              )}

              <div className="bg-electric-50 rounded-xl px-4 py-3">
                <div className="flex items-center gap-2 text-xs text-electric-700">
                  <Key className="w-3.5 h-3.5" />
                  <span className="font-semibold">Key protection: server-managed Group KEK + AES-256 key wrapping</span>
                </div>
                <p className="text-xs text-electric-600 mt-1">
                  Direct mode uses on-chain grants plus optional ABAC. Group mode uses versioned group keys and can also require ABAC policy matching.
                </p>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="animate-fade-in space-y-4">
              <h3 className="text-sm font-semibold text-gray-800 mb-1 flex items-center gap-2">
                <Clock className="w-4 h-4 text-electric-500" /> Access expiry
              </h3>
              <div className="grid grid-cols-2 gap-2">
                {EXPIRY_PRESETS.map((p) => (
                  <button
                    key={p.seconds}
                    onClick={() => setExpiry(p.seconds)}
                    className={`py-2.5 rounded-xl text-sm font-medium border transition-all ${
                      expiry === p.seconds
                        ? "bg-electric-500 border-electric-500 text-white shadow-electric"
                        : "border-gray-200 text-gray-600 hover:border-electric-300"
                    }`}
                  >
                    {p.label}
                  </button>
                ))}
              </div>

              {/* ─── Policy Template Picker ──────────────────────────────────────────── */}
              <div className="bg-gray-50 rounded-xl p-4 border border-gray-100">
                <h4 className="text-sm font-semibold text-gray-800 mb-1">Access Policy Template</h4>
                <p className="text-xs text-gray-400 mb-3">
                  Pick a real-world scenario to auto-fill the file policy and recipient attributes below.
                  Leave unselected for no ABAC restriction (explicit grant only).
                </p>
                <div className="grid grid-cols-1 gap-1.5">
                  {POLICY_TEMPLATES.map((t) => (
                    <button
                      key={t.id}
                      onClick={() => {
                        if (selectedTemplate === t.id) {
                          setSelectedTemplate(null);
                          setFilePolicyAttrs([{ ...EMPTY_ATTR }]);
                          setRecipientAttrs([{ ...EMPTY_ATTR }]);
                        } else {
                          setSelectedTemplate(t.id);
                          setFilePolicyAttrs(t.policy);
                          setRecipientAttrs(t.recipient);
                        }
                      }}
                      className={`flex items-center gap-3 px-3 py-2 rounded-xl border text-left transition-all ${
                        selectedTemplate === t.id
                          ? "bg-electric-50 border-electric-400"
                          : "border-gray-200 bg-white hover:border-electric-300"
                      }`}
                    >
                      <span className="text-base flex-shrink-0">{t.emoji}</span>
                      <div className="flex-1 min-w-0">
                        <div className="text-xs font-semibold text-gray-800">{t.label}</div>
                        <div className="text-[10px] text-gray-400 mt-0.5">{t.description}</div>
                      </div>
                      {selectedTemplate === t.id && (
                        <Check className="w-3.5 h-3.5 text-electric-500 flex-shrink-0" />
                      )}
                    </button>
                  ))}
                </div>
              </div>

              {renderAttributeEditor({
                title: "ABAC File Policy",
                subtitle: "Optional. Users must match all of these attributes when a file policy is active.",
                attrs: filePolicyAttrs,
                setter: setFilePolicyAttrs,
              })}

              {mode === "direct" && (
                <div className="rounded-xl border border-gray-100 bg-gray-50 p-4">
                  <div className="text-xs font-semibold text-gray-700">Recipient Role Assignment</div>
                  <div className="text-xs text-gray-500 mt-1">
                    Disabled in strict mode. Roles are issued only by trusted issuers in Settings.
                  </div>
                </div>
              )}
            </div>
          )}

          {step === 3 && (
            <div className="animate-fade-in space-y-4">
              <h3 className="text-sm font-semibold text-gray-800 mb-3">Confirm & Share</h3>

              <div className="bg-gray-50 rounded-xl divide-y divide-gray-100">
                <div className="flex items-center justify-between px-4 py-3">
                  <span className="text-xs text-gray-400">Mode</span>
                  <span className="text-xs font-medium text-gray-800">{mode === "direct" ? "Direct Wallet" : "Group"}</span>
                </div>
                <div className="flex items-center justify-between px-4 py-3">
                  <span className="text-xs text-gray-400">Target</span>
                  <span className="text-xs font-medium text-gray-800 font-mono">
                    {mode === "direct"
                      ? `${recipient.slice(0, 16)}...${recipient.slice(-8)}`
                      : `${selectedGroup?.name || "-"} (${selectedGroup?.memberCount || 0} members)`}
                  </span>
                </div>
                <div className="flex items-center justify-between px-4 py-3">
                  <span className="text-xs text-gray-400">Expiry</span>
                  <span className="text-xs font-medium text-gray-800">{expiryLabel}</span>
                </div>
                <div className="flex items-center justify-between px-4 py-3">
                  <span className="text-xs text-gray-400">ABAC Policy</span>
                  <span className="text-xs font-medium text-gray-800">
                    {filePolicyTags.length > 0 ? `${filePolicyTags.length} required attribute(s)` : "No policy"}
                  </span>
                </div>
                {mode === "direct" && (
                  <div className="px-4 py-3">
                    <div className="text-xs text-gray-400">Recipient Attributes</div>
                    <div className="text-xs font-medium text-gray-800 mt-0.5">
                      Issuer-managed in strict mode (sender cannot assign roles during share).
                    </div>
                  </div>
                )}
              </div>

              {(isSharing || txStatus.done) && (
                <div className="space-y-2">
                  {(mode === "direct" ? directProgressSteps : groupProgressSteps).map(({ n, label }) => (
                    <div key={n} className="flex items-center gap-3 text-xs">
                      <div className={`w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 ${
                        txStatus.done && n <= txStatus.step ? "bg-green-100" :
                        txStatus.step === n ? "bg-electric-100" : "bg-gray-100"
                      }`}>
                        {(txStatus.done && n <= txStatus.step) || txStatus.done
                          ? <Check className="w-3 h-3 text-green-600" />
                          : txStatus.step === n
                            ? <Loader2 className="w-3 h-3 text-electric-500 animate-spin" />
                            : <span className="text-gray-400 text-[10px]">{n}</span>}
                      </div>
                      <span className={
                        txStatus.done ? "text-green-700" :
                        txStatus.step === n ? "text-electric-700" : "text-gray-400"
                      }>
                        {mode === "direct"
                          ? `Transaction ${n}/${directProgressSteps.length}: ${label}`
                          : `Step ${n}/${groupProgressSteps.length}: ${label}`}
                      </span>
                    </div>
                  ))}
                </div>
              )}

              {txStatus.error && (
                <div className="bg-red-50 text-red-600 text-xs rounded-xl px-4 py-3">
                  {txStatus.error}
                </div>
              )}
            </div>
          )}
        </div>

        <div className="flex items-center justify-between p-6 border-t border-gray-100">
          <button
            onClick={() => step > 1 ? setStep((s) => s - 1) : onClose()}
            className="btn-secondary flex items-center gap-2"
            disabled={isSharing}
          >
            <ChevronLeft className="w-4 h-4" />
            {step === 1 ? "Cancel" : "Back"}
          </button>

          {step < 3 ? (
            <button
              onClick={() => setStep((s) => s + 1)}
              disabled={(mode === "direct" && !recipient.match(/^0x[0-9a-fA-F]{40}$/)) || (mode === "group" && !selectedGroupId)}
              className="btn-primary flex items-center gap-2"
            >
              Next <ChevronRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              onClick={handleShare}
              disabled={isSharing || txStatus.done}
              className="btn-primary flex items-center gap-2"
            >
              {isSharing ? <><Loader2 className="w-4 h-4 animate-spin" /> Sharing...</>
                : txStatus.done ? <><Check className="w-4 h-4" /> Shared!</>
                : "Share Now"}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
