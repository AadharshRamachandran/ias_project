import { ethers } from "ethers";
import FileRegistryABI from "../../../blockchain/artifacts/contracts/FileRegistry.sol/FileRegistry.json";
import AccessControlABI from "../../../blockchain/artifacts/contracts/AccessControl.sol/FileAccessControl.json";
import TimeBoundPermissionsABI from "../../../blockchain/artifacts/contracts/TimeBoundPermissions.sol/TimeBoundPermissions.json";
import GDPRComplianceABI from "../../../blockchain/artifacts/contracts/GDPRCompliance.sol/GDPRCompliance.json";
// Fallback if addresses file wasn't generated correctly by deploy.js yet
import Addresses from "../contracts/addresses.json";

const CONTRACTS = Addresses.contracts || Addresses;
const CHAIN_ID = Number(import.meta.env.VITE_CHAIN_ID || 1337);
const CHAIN_ID_HEX = `0x${CHAIN_ID.toString(16)}`;
const RPC_URL = import.meta.env.VITE_RPC_URL || "http://127.0.0.1:8545";
const CHAIN_NAME = import.meta.env.VITE_CHAIN_NAME || "Hardhat Local";
const CHAIN_CURRENCY_SYMBOL = import.meta.env.VITE_CHAIN_CURRENCY_SYMBOL || "ETH";

export const NETWORK_CONFIG = {
    chainId: CHAIN_ID,
    chainIdHex: CHAIN_ID_HEX,
    chainName: CHAIN_NAME,
    rpcUrl: RPC_URL,
    currencySymbol: CHAIN_CURRENCY_SYMBOL,
};

export async function getProvider() {
    if (!window.ethereum) throw new Error("MetaMask not found");
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    await provider.send("eth_requestAccounts", []);

    // Attempt to auto-switch to the configured EVM network.
    try {
        await window.ethereum.request({
            method: 'wallet_switchEthereumChain',
            params: [{ chainId: NETWORK_CONFIG.chainIdHex }],
        });
    } catch (switchError) {
        // Error 4902 implies the chain is not yet added to MetaMask
        if (switchError.code === 4902) {
            try {
                await window.ethereum.request({
                    method: 'wallet_addEthereumChain',
                    params: [{
                        chainId: NETWORK_CONFIG.chainIdHex,
                        chainName: NETWORK_CONFIG.chainName,
                        rpcUrls: [NETWORK_CONFIG.rpcUrl],
                        nativeCurrency: {
                            name: 'Ethereum',
                            symbol: NETWORK_CONFIG.currencySymbol,
                            decimals: 18
                        }
                    }],
                });
            } catch (addError) {
                console.warn("Failed to add Hardhat network:", addError);
            }
        } else {
            console.warn("Failed to switch to Hardhat network:", switchError);
        }
    }

    return provider;
}

export async function getSigner() {
    const provider = await getProvider();
    return provider.getSigner();
}

function getContract(address, abi, signerOrProvider) {
    return new ethers.Contract(address, abi.abi || abi, signerOrProvider);
}

export async function getFileRegistry(signer) {
    return getContract(CONTRACTS.FileRegistry, FileRegistryABI, signer);
}

export async function getAccessControl(signer) {
    return getContract(CONTRACTS.FileAccessControl, AccessControlABI, signer);
}

export async function getTimeBoundPermissions(signer) {
    return getContract(CONTRACTS.TimeBoundPermissions, TimeBoundPermissionsABI, signer);
}

export async function getGDPRCompliance(signer) {
    return getContract(CONTRACTS.GDPRCompliance, GDPRComplianceABI, signer);
}

export async function getZKPVerifier(signer) {
    throw new Error(
        "ZKPVerifier artifact is not available in midsem submission/blockchain/artifacts. " +
        "Compile/deploy ZKPVerifier or remove ZKP calls in this build."
    );
}

export async function signAuthMessage(signer) {
    const address = await signer.getAddress();
    const timestamp = Math.floor(Date.now() / 1000);
    const nonce = ethers.utils.hexlify(ethers.utils.randomBytes(8));
    const message = `SecureFileShare:${timestamp}:${address}:${nonce}`;
    const signature = await signer.signMessage(message);
    return { address, signature, message };
}
