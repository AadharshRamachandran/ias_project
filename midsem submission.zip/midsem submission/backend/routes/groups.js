"use strict";

const express = require("express");
const router = express.Router();

const { authMiddleware } = require("../middleware/auth");
const groupSvc = require("../services/groupKeyService");
const materialsSvc = require("../services/materialsService");
const gdprSvc = require("../services/gdprService");

router.get("/", authMiddleware, (req, res) => {
    try {
        const groups = groupSvc.listGroupsForUser(req.verifiedAddress);
        return res.json({ success: true, groups });
    } catch (err) {
        console.error("[groups/list]", err);
        return res.status(500).json({ error: err.message });
    }
});

router.post("/", authMiddleware, (req, res) => {
    try {
        const { name, members } = req.body || {};
        const group = groupSvc.createGroup({
            ownerAddress: req.verifiedAddress,
            name,
            members: Array.isArray(members) ? members : [],
        });
        return res.json({ success: true, group });
    } catch (err) {
        console.error("[groups/create]", err);
        return res.status(400).json({ error: err.message });
    }
});

router.get("/:groupId/members", authMiddleware, (req, res) => {
    try {
        const { groupId } = req.params;
        const groups = groupSvc.listGroupsForUser(req.verifiedAddress);
        const inGroup = groups.some((g) => g.groupId === String(groupId));
        if (!inGroup) return res.status(403).json({ error: "Not a member of this group" });

        const members = groupSvc.listGroupMembers(groupId);
        return res.json({ success: true, members });
    } catch (err) {
        console.error("[groups/members/list]", err);
        return res.status(500).json({ error: err.message });
    }
});

router.post("/:groupId/members", authMiddleware, (req, res) => {
    try {
        const { groupId } = req.params;
        const { memberAddress, role } = req.body || {};
        const result = groupSvc.addMember({
            groupId,
            requesterAddress: req.verifiedAddress,
            memberAddress,
            role,
        });
        return res.json({ success: true, ...result });
    } catch (err) {
        console.error("[groups/members/add]", err);
        return res.status(400).json({ error: err.message });
    }
});

router.delete("/:groupId/members/:memberAddress", authMiddleware, (req, res) => {
    try {
        const { groupId, memberAddress } = req.params;
        const result = groupSvc.removeMember({
            groupId,
            requesterAddress: req.verifiedAddress,
            memberAddress,
        });
        return res.json({ success: true, ...result });
    } catch (err) {
        console.error("[groups/members/remove]", err);
        return res.status(400).json({ error: err.message });
    }
});

router.post("/share", authMiddleware, (req, res) => {
    try {
        const { groupId, fileId, expiryDurationSeconds } = req.body || {};
        if (!groupId || fileId === undefined || fileId === null) {
            return res.status(400).json({ error: "groupId and fileId are required" });
        }

        const materials = materialsSvc.getFileMaterials(fileId);
        if (!materials) {
            return res.status(400).json({
                error: "Missing decryption materials for this fileId",
                fix: "Ensure uploader completed /api/materials/register for this file",
            });
        }

        if (String(materials.ownerAddress).toLowerCase() !== req.verifiedAddress) {
            return res.status(403).json({ error: "Only file owner can share to groups" });
        }

        const share = groupSvc.shareFileToGroup({
            groupId,
            fileId,
            ownerAddress: req.verifiedAddress,
            aesKeyHex: materials.aesKeyHex,
            expiryDurationSeconds,
        });

        gdprSvc.logAccess(req.verifiedAddress, String(fileId), "GROUP_SHARE_GRANTED", null);

        return res.json({
            success: true,
            share,
            message: "Group share created. Active members can access until expiry.",
        });
    } catch (err) {
        console.error("[groups/share]", err);
        return res.status(400).json({ error: err.message });
    }
});

module.exports = router;
